import java.util.LinkedList;
import java.util.Queue;

public class Cola {

    private Queue<Cola> listaColas;

    public Cola() {
        listaColas=new LinkedList<>();
        inicializarCola();
    }


    private void inicializarCola() {

        listaColas.add(new Cola(10));
        listaColas.add(new Cola(2, "HONDA", 1500, 2345.67, 2019));
        listaColas.add(new Cola(3, "PULSAR", 1800, 3456.78, 2021));
        listaColas.add(new Cola(4, "SUZUKI", 2000, 4567.89, 2022));
        listaColas.add(new Cola(5, "BMW", 1400, 5678.90, 2018));
        listaColas.add(new Cola(6, "HONDA", 1700, 6789.01, 2023));
    }

    public void encolar(Cola cola)
    {
        listaColas.add(cola);

    }

    public String listarColas()
    {
        String acum="";
        for (Cola x: listaColas)
        {
            acum+=x.toString();
        }
        return acum;
    }

    public Cola desencolar() {
        return listaColas.poll();
    }

    public boolean estaVacia() {
        return listaColas.isEmpty();
    }

    public void mostrarCola() {
        for (Cola cola : listaColas) {
            System.out.println(cola);
        }
    }
    public void nuevoElementos(){
    }
}



