public class Motocicleta {

    private int n_serie;
    private String marca;
    private int anio;
    private int cilindraje;
    private double matricula;



    public Motocicleta(int n_serie, String marca, int anio, int cilindraje, double matricula){
        this.n_serie = n_serie;
        this.marca = marca;
        this.anio = anio;
        this.cilindraje = cilindraje;
        this.matricula = matricula;
    }


    public int getN_serie() {
        return n_serie;
    }

    public void setN_serie(int n_serie) {
        this.n_serie = n_serie;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    public double getMatricula() {
        return matricula;
    }

    public void setMatricula(double matricula) {
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Motocicleta{" +
                "n_serie=" + n_serie +
                ", marca='" + marca + '\'' +
                ", anio=" + anio +
                ", cilindraje=" + cilindraje +
                ", matricula=" + matricula +
                '}';
    }
}
