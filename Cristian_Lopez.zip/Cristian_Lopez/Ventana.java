import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTabbedPane tabbedPane1;
    private JTextArea txtCola;
    private JComboBox<String> comboBox1;
    private JTextArea textArea1;
    private JButton btnAgregar;
    private JTextField txtDatos;
    private JButton btnDesencolar;

    private Cola co;

    public Ventana() {
        co = new Cola();
        inicializarComponentes();


        comboBox1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                co.listarColas(comboBox1.getSelectedItem().toString());
                
                
            }
        });
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    private void inicializarComponentes() {
    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

